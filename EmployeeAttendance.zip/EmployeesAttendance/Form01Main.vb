﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SQLite

Namespace EmployeesAttendance



	Partial Public Class Form01Main
		Inherits Form


		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form01Main_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
            checkAndCreateDb()
		End Sub

		Private Sub btnShowEmployees_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnShowEmployees.Click
			Dim frmEmployees As New Form02Employees()
			frmEmployees.ShowDialog()
		End Sub

        Private Sub btnAttendance_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnShowAttendance.Click
            Dim newAttendance As New Form04Attendance()
            newAttendance.ShowDialog()
        End Sub

       
    End Class

	

End Namespace
