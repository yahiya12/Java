﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Namespace EmployeesAttendance
	Partial Public Class Form04Attendance
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Me.panel1 = New System.Windows.Forms.Panel()
            Me.btnPrevious = New System.Windows.Forms.Button()
            Me.btnNext = New System.Windows.Forms.Button()
            Me.dtpAttendanceDate = New System.Windows.Forms.DateTimePicker()
            Me.dgvAttendance = New System.Windows.Forms.DataGridView()
            Me.panel1.SuspendLayout()
            CType(Me.dgvAttendance, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'panel1
            '
            Me.panel1.Controls.Add(Me.btnPrevious)
            Me.panel1.Controls.Add(Me.btnNext)
            Me.panel1.Controls.Add(Me.dtpAttendanceDate)
            Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
            Me.panel1.Location = New System.Drawing.Point(0, 0)
            Me.panel1.Name = "panel1"
            Me.panel1.Size = New System.Drawing.Size(348, 41)
            Me.panel1.TabIndex = 0
            '
            'btnPrevious
            '
            Me.btnPrevious.Dock = System.Windows.Forms.DockStyle.Left
            Me.btnPrevious.Location = New System.Drawing.Point(0, 0)
            Me.btnPrevious.Name = "btnPrevious"
            Me.btnPrevious.Size = New System.Drawing.Size(75, 41)
            Me.btnPrevious.TabIndex = 2
            Me.btnPrevious.Text = "<< Previous"
            Me.btnPrevious.UseVisualStyleBackColor = True
            '
            'btnNext
            '
            Me.btnNext.Dock = System.Windows.Forms.DockStyle.Right
            Me.btnNext.Location = New System.Drawing.Point(273, 0)
            Me.btnNext.Name = "btnNext"
            Me.btnNext.Size = New System.Drawing.Size(75, 41)
            Me.btnNext.TabIndex = 1
            Me.btnNext.Text = "Next >>"
            Me.btnNext.UseVisualStyleBackColor = True
            '
            'dtpAttendanceDate
            '
            Me.dtpAttendanceDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
            Me.dtpAttendanceDate.CustomFormat = ""
            Me.dtpAttendanceDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.dtpAttendanceDate.Location = New System.Drawing.Point(89, 9)
            Me.dtpAttendanceDate.Name = "dtpAttendanceDate"
            Me.dtpAttendanceDate.ShowUpDown = True
            Me.dtpAttendanceDate.Size = New System.Drawing.Size(172, 26)
            Me.dtpAttendanceDate.TabIndex = 0
            '
            'dgvAttendance
            '
            Me.dgvAttendance.AllowUserToAddRows = False
            Me.dgvAttendance.AllowUserToDeleteRows = False
            Me.dgvAttendance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
            Me.dgvAttendance.Dock = System.Windows.Forms.DockStyle.Fill
            Me.dgvAttendance.Location = New System.Drawing.Point(0, 41)
            Me.dgvAttendance.Name = "dgvAttendance"
            Me.dgvAttendance.Size = New System.Drawing.Size(348, 514)
            Me.dgvAttendance.TabIndex = 1
            '
            'Form04Attendance
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(348, 555)
            Me.Controls.Add(Me.dgvAttendance)
            Me.Controls.Add(Me.panel1)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.Name = "Form04Attendance"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Form04Attendance"
            Me.panel1.ResumeLayout(False)
            CType(Me.dgvAttendance, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)

        End Sub

		#End Region

		Private panel1 As System.Windows.Forms.Panel
		Private WithEvents dtpAttendanceDate As System.Windows.Forms.DateTimePicker
		Private WithEvents dgvAttendance As System.Windows.Forms.DataGridView
		Private WithEvents btnPrevious As System.Windows.Forms.Button
		Private WithEvents btnNext As System.Windows.Forms.Button
	End Class
End Namespace