﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Namespace EmployeesAttendance
	Partial Public Class Form01Main
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Me.btnShowEmployees = New System.Windows.Forms.Button()
            Me.btnShowAttendance = New System.Windows.Forms.Button()
            Me.SuspendLayout()
            '
            'btnShowEmployees
            '
            Me.btnShowEmployees.Anchor = System.Windows.Forms.AnchorStyles.None
            Me.btnShowEmployees.Location = New System.Drawing.Point(37, 51)
            Me.btnShowEmployees.Name = "btnShowEmployees"
            Me.btnShowEmployees.Size = New System.Drawing.Size(165, 125)
            Me.btnShowEmployees.TabIndex = 0
            Me.btnShowEmployees.Text = "Show Employees"
            Me.btnShowEmployees.UseVisualStyleBackColor = True
            '
            'btnShowAttendance
            '
            Me.btnShowAttendance.Anchor = System.Windows.Forms.AnchorStyles.None
            Me.btnShowAttendance.Location = New System.Drawing.Point(236, 51)
            Me.btnShowAttendance.Name = "btnShowAttendance"
            Me.btnShowAttendance.Size = New System.Drawing.Size(165, 125)
            Me.btnShowAttendance.TabIndex = 1
            Me.btnShowAttendance.Text = "Show Attendance"
            Me.btnShowAttendance.UseVisualStyleBackColor = True
            '
            'Form01Main
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(455, 230)
            Me.Controls.Add(Me.btnShowAttendance)
            Me.Controls.Add(Me.btnShowEmployees)
            Me.Name = "Form01Main"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Main Form"
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private WithEvents btnShowEmployees As System.Windows.Forms.Button
        Private WithEvents btnShowAttendance As System.Windows.Forms.Button
    End Class
End Namespace

