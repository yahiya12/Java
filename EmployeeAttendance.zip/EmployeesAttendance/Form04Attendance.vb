﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SQLite

Namespace EmployeesAttendance
	Partial Public Class Form04Attendance
		Inherits Form

		Public Sub New()
			InitializeComponent()
        End Sub

		Private Sub Form04Attendance_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
			initiateColumns()
		End Sub

		Private Sub initiateColumns()
			dgvAttendance.Columns.Clear()

			Dim iIdCol As New DataGridViewTextBoxColumn()
			iIdCol.Name = "ID"
			iIdCol.HeaderText = "ID"
			iIdCol.ReadOnly = True
			iIdCol.Frozen = True
			dgvAttendance.Columns.Add(iIdCol)

			Dim iNameCol As New DataGridViewTextBoxColumn()
			iNameCol.HeaderText = "Name"
			iNameCol.ReadOnly = True
			iNameCol.Frozen = True
			dgvAttendance.Columns.Add(iNameCol)

            Dim iDate As Date = dtpAttendanceDate.Value.Date
            Dim iDayCol As New DataGridViewCheckBoxColumn()
            iDayCol.Name = "DayCol" & iDate.ToString("yyyyMMdd")
            iDayCol.HeaderText = iDate.ToString("dd-MMM-yyyy")
            If iDate.Date <> Date.Now.Date Then
                iDayCol.ReadOnly = True
            End If
            dgvAttendance.Columns.Add(iDayCol)


            sqlite2 = New SQLiteConnection("Data Source=" & sqlitefile)
            sqlite2.Open()
            Dim CommandText As String = "SELECT * FROM Employees"
            Dim sqlda As New SQLiteDataAdapter(CommandText, sqlite2)
            Dim dt As New DataTable()
            sqlda.Fill(dt)
            sqlite2.Close()
            Using dt
                For Each dataRow As DataRow In dt.Rows
                    dgvAttendance.Rows.Add(dataRow("ID"), dataRow("Name"))
                Next dataRow
            End Using

            sqlite2 = New SQLiteConnection("Data Source=" & sqlitefile)
            sqlite2.Open()
            Dim CommandText1 As String = "SELECT * FROM attendance WHERE DateTime = '" & iDate.ToString("dd-MMM-yyyy") & "'"
            Dim sqlda1 As New SQLiteDataAdapter(CommandText1, sqlite2)
            Dim dt1 As New DataTable()
            sqlda1.Fill(dt1)
            sqlite2.Close()
            Using dt1
                For Each row As DataGridViewRow In dgvAttendance.Rows
                    Dim id As Int16 = Convert.ToInt16(row.Cells("ID").Value)
                    Dim thisEmployee As DataRow = dt1.Select("EmployeeID = " & id.ToString() & " AND DateTime = '" & dtpAttendanceDate.Value.ToString("dd-MMM-yyyy") & "'").FirstOrDefault()
                    If thisEmployee IsNot Nothing Then
                        row.Cells("DayCol" & iDate.ToString("yyyyMMdd")).Value = thisEmployee("Attendance")
                    End If
                Next row
            End Using

        End Sub

        Private Sub dtpAttendanceDate_ValueChanged(ByVal sender As Object, ByVal e As EventArgs) Handles dtpAttendanceDate.ValueChanged
            initiateColumns()
        End Sub

        Private Sub dgvAttendance_CellContentClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvAttendance.CellContentClick
            dgvAttendance.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End Sub
        Private Sub dgvAttendance_CellValueChanged(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvAttendance.CellValueChanged

            Dim editedCell = Me.dgvAttendance.Rows(e.RowIndex).Cells(e.ColumnIndex)
            Dim newValue = editedCell.Value

            Dim EmployeeID As Int16 = Convert.ToInt16(dgvAttendance.Rows(e.RowIndex).Cells(0).Value)
            Dim UniqueID As String = dgvAttendance.Columns(e.ColumnIndex).HeaderText & "_" & EmployeeID.ToString("0000")
            sqlite2 = New SQLiteConnection("Data Source=" & sqlitefile)
            sqlite2.Open()
            Dim sqlInsert As String = "insert or replace into attendance (EntryID, EmployeeID, DateTime, Attendance) values ('" & UniqueID & "', " & EmployeeID.ToString() & ", '" & dgvAttendance.Columns(e.ColumnIndex).HeaderText & "', " & Convert.ToInt16(newValue) & ")"
            Dim insertSQL As New SQLiteCommand(sqlInsert, sqlite2)
            insertSQL.ExecuteNonQuery()
            sqlite2.Close()
        End Sub

		Private Sub btnPrevious_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnPrevious.Click
			dtpAttendanceDate.Value = dtpAttendanceDate.Value.AddDays(-1)

		End Sub

		Private Sub btnNext_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnNext.Click
			dtpAttendanceDate.Value = dtpAttendanceDate.Value.AddDays(1)
		End Sub
	End Class
End Namespace
