﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SQLite

Namespace EmployeesAttendance
	Partial Public Class Form03AddEmployee
		Inherits Form

		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub btnAddEmployee_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddEmployee.Click
			If tbEmployeesName.Text <> "" AndAlso tbEmployeesFatherName.Text <> "" AndAlso tbEmployeesAge.Text <> "" Then
                sqlite2 = New SQLiteConnection("Data Source=" & sqlitefile)
                sqlite2.Open()

                'INSERT INTO Employees (Name, Age, FathersName, Department, Address) VALUES ('" & tbEmplyeesName.Text & "', 24, 'Yahia Father Name', 'Dot Net', 'Madipakkam')
                Dim sqlInsert As String = "INSERT INTO Employees (Name, Age, FathersName, Department, Address) VALUES ('" & tbEmployeesName.Text & "', " & tbEmployeesAge.Text & ", '" & tbEmployeesFatherName.Text & "', '" & tbEmployeesDepartment.Text & "', '" & tbEmployeesAddress.Text & "')"
                Dim insertSQL As New SQLiteCommand(sqlInsert, sqlite2)
                insertSQL.ExecuteNonQuery()
                sqlite2.Close()
				Me.Close()
			End If
		End Sub

        Private Sub tbEmployeesAge_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbEmployeesAge.Leave
            Try
                tbEmployeesAge.Text = Convert.ToInt16(tbEmployeesAge.Text).ToString
            Catch ex As Exception
                tbEmployeesAge.Text = "1"
            End Try
        End Sub

       
    End Class
End Namespace
