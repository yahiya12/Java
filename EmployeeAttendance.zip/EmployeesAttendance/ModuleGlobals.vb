﻿Imports System.Data.SQLite
Public Module Globals
    Public sqlitefile As String = ""
    Public sqlite2 As SQLiteConnection

    Public Sub checkAndCreateDb()
        sqlitefile = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\Employees.sqlite"
        If Not System.IO.File.Exists(sqlitefile) Then
            SQLiteConnection.CreateFile(sqlitefile)
            sqlite2 = New SQLiteConnection("Data Source=" & sqlitefile)
            'sqlite2.ConnectionString = "Data Source=" & sqlitefile
            sqlite2.Open()
            Dim sqlEmployeesTable As String = "CREATE TABLE IF NOT EXISTS Employees (ID INTEGER PRIMARY KEY autoincrement, Name varchar(50) NOT NULL, Age int, FathersName varchar(50), Department varchar(20), Address text)"
            Dim command1 As New SQLiteCommand(sqlEmployeesTable, sqlite2)
            command1.ExecuteNonQuery()
            Dim sqlAttendanceTable As String = "CREATE TABLE IF NOT EXISTS attendance (EntryID varchar(20) PRIMARY KEY, EmployeeID int, DateTime text, Attendance int DEFAULT 0)"
            Dim command2 As New SQLiteCommand(sqlAttendanceTable, sqlite2)
            command2.ExecuteNonQuery()
            sqlite2.Close()

        End If
    End Sub
End Module