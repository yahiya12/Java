﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Windows.Forms
Imports System.Data.SQLite

Namespace EmployeesAttendance

	Partial Public Class Form02Employees
		Inherits Form

		Public Sub New()
			InitializeComponent()
		End Sub

		Private Sub Form02Employees_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
			refreshEmployees()
		End Sub

		Private Sub btnAddEmployee_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAddEmployee.Click
			Dim newEmployeeForm As New Form03AddEmployee()
			newEmployeeForm.ShowDialog()
			refreshEmployees()
		End Sub

		Private Sub refreshEmployees()
            sqlite2 = New SQLiteConnection("Data Source=" & sqlitefile)
            sqlite2.Open()
			Dim CommandText As String = "SELECT * FROM Employees"
            Dim sqlda As New SQLiteDataAdapter(CommandText, sqlite2)
			Dim dt As New DataTable()
			Using dt
				sqlda.Fill(dt)
				dgvEmployees.DataSource = dt
			End Using
		End Sub
	End Class
End Namespace
