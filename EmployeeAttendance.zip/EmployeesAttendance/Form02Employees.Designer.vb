﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Namespace EmployeesAttendance
	Partial Public Class Form02Employees
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.panel1 = New System.Windows.Forms.Panel()
			Me.btnAddEmployee = New System.Windows.Forms.Button()
			Me.dgvEmployees = New System.Windows.Forms.DataGridView()
			Me.panel1.SuspendLayout()
			CType(Me.dgvEmployees, System.ComponentModel.ISupportInitialize).BeginInit()
			Me.SuspendLayout()
			' 
			' panel1
			' 
			Me.panel1.Controls.Add(Me.btnAddEmployee)
			Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
			Me.panel1.Location = New System.Drawing.Point(0, 0)
			Me.panel1.Name = "panel1"
			Me.panel1.Size = New System.Drawing.Size(751, 33)
			Me.panel1.TabIndex = 0
			' 
			' btnAddEmployee
			' 
			Me.btnAddEmployee.Dock = System.Windows.Forms.DockStyle.Right
			Me.btnAddEmployee.Location = New System.Drawing.Point(611, 0)
			Me.btnAddEmployee.Name = "btnAddEmployee"
			Me.btnAddEmployee.Size = New System.Drawing.Size(140, 33)
			Me.btnAddEmployee.TabIndex = 0
			Me.btnAddEmployee.Text = "Add Employee"
			Me.btnAddEmployee.UseVisualStyleBackColor = True
'INSTANT VB NOTE: The following InitializeComponent event wireup was converted to a 'Handles' clause:
'ORIGINAL LINE: this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
			' 
			' dgvEmployees
			' 
			Me.dgvEmployees.AllowUserToAddRows = False
			Me.dgvEmployees.AllowUserToDeleteRows = False
			Me.dgvEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
			Me.dgvEmployees.Dock = System.Windows.Forms.DockStyle.Fill
			Me.dgvEmployees.Location = New System.Drawing.Point(0, 33)
			Me.dgvEmployees.Name = "dgvEmployees"
			Me.dgvEmployees.Size = New System.Drawing.Size(751, 468)
			Me.dgvEmployees.TabIndex = 1
			' 
			' Form02Employees
			' 
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.ClientSize = New System.Drawing.Size(751, 501)
			Me.Controls.Add(Me.dgvEmployees)
			Me.Controls.Add(Me.panel1)
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
			Me.Name = "Form02Employees"
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "FormEmployees"
'INSTANT VB NOTE: The following InitializeComponent event wireup was converted to a 'Handles' clause:
'ORIGINAL LINE: this.Load += new System.EventHandler(this.Form02Employees_Load);
			Me.panel1.ResumeLayout(False)
			CType(Me.dgvEmployees, System.ComponentModel.ISupportInitialize).EndInit()
			Me.ResumeLayout(False)

		End Sub

		#End Region

		Private panel1 As System.Windows.Forms.Panel
		Private WithEvents btnAddEmployee As System.Windows.Forms.Button
		Private dgvEmployees As System.Windows.Forms.DataGridView
	End Class
End Namespace