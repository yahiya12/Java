﻿'========================================================================
' This conversion was produced by the Free Edition of
' Instant VB courtesy of Tangible Software Solutions.
' Order the Premium Edition at https://www.tangiblesoftwaresolutions.com
'========================================================================

Namespace EmployeesAttendance
	Partial Public Class Form03AddEmployee
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(ByVal disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
            Me.tbEmployeesName = New System.Windows.Forms.TextBox()
            Me.tbEmployeesFatherName = New System.Windows.Forms.TextBox()
            Me.tbEmployeesAge = New System.Windows.Forms.TextBox()
            Me.tbEmployeesDepartment = New System.Windows.Forms.TextBox()
            Me.tbEmployeesAddress = New System.Windows.Forms.TextBox()
            Me.label1 = New System.Windows.Forms.Label()
            Me.label2 = New System.Windows.Forms.Label()
            Me.label3 = New System.Windows.Forms.Label()
            Me.label4 = New System.Windows.Forms.Label()
            Me.label5 = New System.Windows.Forms.Label()
            Me.btnAddEmployee = New System.Windows.Forms.Button()
            Me.SuspendLayout()
            '
            'tbEmployeesName
            '
            Me.tbEmployeesName.Location = New System.Drawing.Point(122, 40)
            Me.tbEmployeesName.Name = "tbEmployeesName"
            Me.tbEmployeesName.Size = New System.Drawing.Size(170, 20)
            Me.tbEmployeesName.TabIndex = 0
            '
            'tbEmployeesFatherName
            '
            Me.tbEmployeesFatherName.Location = New System.Drawing.Point(122, 66)
            Me.tbEmployeesFatherName.Name = "tbEmployeesFatherName"
            Me.tbEmployeesFatherName.Size = New System.Drawing.Size(170, 20)
            Me.tbEmployeesFatherName.TabIndex = 1
            '
            'tbEmployeesAge
            '
            Me.tbEmployeesAge.Location = New System.Drawing.Point(122, 92)
            Me.tbEmployeesAge.Name = "tbEmployeesAge"
            Me.tbEmployeesAge.Size = New System.Drawing.Size(170, 20)
            Me.tbEmployeesAge.TabIndex = 2
            '
            'tbEmployeesDepartment
            '
            Me.tbEmployeesDepartment.Location = New System.Drawing.Point(122, 118)
            Me.tbEmployeesDepartment.Name = "tbEmployeesDepartment"
            Me.tbEmployeesDepartment.Size = New System.Drawing.Size(170, 20)
            Me.tbEmployeesDepartment.TabIndex = 3
            '
            'tbEmployeesAddress
            '
            Me.tbEmployeesAddress.Location = New System.Drawing.Point(122, 144)
            Me.tbEmployeesAddress.Name = "tbEmployeesAddress"
            Me.tbEmployeesAddress.Size = New System.Drawing.Size(170, 20)
            Me.tbEmployeesAddress.TabIndex = 4
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.Location = New System.Drawing.Point(81, 43)
            Me.label1.Name = "label1"
            Me.label1.Size = New System.Drawing.Size(35, 13)
            Me.label1.TabIndex = 5
            Me.label1.Text = "Name"
            '
            'label2
            '
            Me.label2.AutoSize = True
            Me.label2.Location = New System.Drawing.Point(43, 69)
            Me.label2.Name = "label2"
            Me.label2.Size = New System.Drawing.Size(73, 13)
            Me.label2.TabIndex = 6
            Me.label2.Text = "Fathers Name"
            '
            'label3
            '
            Me.label3.AutoSize = True
            Me.label3.Location = New System.Drawing.Point(90, 95)
            Me.label3.Name = "label3"
            Me.label3.Size = New System.Drawing.Size(26, 13)
            Me.label3.TabIndex = 7
            Me.label3.Text = "Age"
            '
            'label4
            '
            Me.label4.AutoSize = True
            Me.label4.Location = New System.Drawing.Point(54, 121)
            Me.label4.Name = "label4"
            Me.label4.Size = New System.Drawing.Size(62, 13)
            Me.label4.TabIndex = 8
            Me.label4.Text = "Department"
            '
            'label5
            '
            Me.label5.AutoSize = True
            Me.label5.Location = New System.Drawing.Point(71, 147)
            Me.label5.Name = "label5"
            Me.label5.Size = New System.Drawing.Size(45, 13)
            Me.label5.TabIndex = 9
            Me.label5.Text = "Address"
            '
            'btnAddEmployee
            '
            Me.btnAddEmployee.Location = New System.Drawing.Point(122, 170)
            Me.btnAddEmployee.Name = "btnAddEmployee"
            Me.btnAddEmployee.Size = New System.Drawing.Size(170, 26)
            Me.btnAddEmployee.TabIndex = 10
            Me.btnAddEmployee.Text = "Add Employee"
            Me.btnAddEmployee.UseVisualStyleBackColor = True
            '
            'Form03AddEmployee
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.ClientSize = New System.Drawing.Size(370, 256)
            Me.Controls.Add(Me.btnAddEmployee)
            Me.Controls.Add(Me.label5)
            Me.Controls.Add(Me.label4)
            Me.Controls.Add(Me.label3)
            Me.Controls.Add(Me.label2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.tbEmployeesAddress)
            Me.Controls.Add(Me.tbEmployeesDepartment)
            Me.Controls.Add(Me.tbEmployeesAge)
            Me.Controls.Add(Me.tbEmployeesFatherName)
            Me.Controls.Add(Me.tbEmployeesName)
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
            Me.Name = "Form03AddEmployee"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Add Employee"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

		#End Region

		Private tbEmployeesName As System.Windows.Forms.TextBox
		Private tbEmployeesFatherName As System.Windows.Forms.TextBox
        Private WithEvents tbEmployeesAge As System.Windows.Forms.TextBox
		Private tbEmployeesDepartment As System.Windows.Forms.TextBox
		Private tbEmployeesAddress As System.Windows.Forms.TextBox
		Private label1 As System.Windows.Forms.Label
		Private label2 As System.Windows.Forms.Label
		Private label3 As System.Windows.Forms.Label
		Private label4 As System.Windows.Forms.Label
		Private label5 As System.Windows.Forms.Label
		Private WithEvents btnAddEmployee As System.Windows.Forms.Button
	End Class
End Namespace