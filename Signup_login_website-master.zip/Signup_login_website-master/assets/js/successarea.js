$(document).ready(function(){
		$(".success-area").fadeOut();
		$(".success-area").fadeIn(5000);
	})