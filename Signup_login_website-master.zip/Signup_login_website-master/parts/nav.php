<nav class="navbar navbar-expand-sm navbar-light bg-light custom-nav">

<div class="container">
	<a href="#" class="navbar-brand">Signup_login_form</a>
	<button type="button" class="navbar-toggler" data-target="#mynav">
		<span class="navbar-toggler-icon"></span>
	</button><!--button-->
	<div class="collapse navbar-collapse" id="mynav">
<ul class="navbar-nav ml-auto">
	<li class="nav-item">
		<a href="#" class="nav-link">Home</a>
	</li>
</ul>
</div>
</div>
</nav>